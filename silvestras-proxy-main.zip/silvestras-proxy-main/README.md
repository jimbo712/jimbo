Silviozas-Proxy
Growtopia Silviozas Proxy Source

How to use
Build with Release x64

Start proxy -> auto patch hosts -> Works as supposed

Features
[P] Visual Clothes & Effects Are Now Fully Visible To Other Proxy Users!
Removed ADS (Advertisement background) on No-Weather Worlds;
/mac Displays Your Current Mac Address;
Added Moderator Checker In Worlds -> /hidden;
/unall -> Automatically Pathfinds To World Lock & Removes Everyone's Access (You Have To Be The Owner);
/wrenchunall -> Enables Fast Everyone's Access Removal On Wrenching Any Lock;
Added /check -> Displays Useful Account Info For Reselling Accounts;
/tree -> Show Tree Fruits;
/render -> Renders An Image Of The Current World;
Added Fast Dice& Show Ping& Show Public Entrances -> /options;
Added Visual Punch/Place Effect While Autofarming;
/logout -> logs you out to login menu.
/chest -> See Chest Items.
Visual Gem Amount Display On Gem Spawn (/options).
/logoff -> logs off to login page.
/save -> Join Save World
/setsave -> Set A Save World
/re -> Performs A Last Used Command.
/w1 /w2 /p1 /p2 etc. shortcuts
Mod Detect V2.
Visual Titles Now Don't Go Away When You Join Another World!
Added "show effect area" in /autocollect;
Added Full Device Spoofing on login. No More Mods Tracking by device!
Added Discord RPC -> Proxy will show up as a game in discord.
Added Skip Dialog For Faster Autosurg!
Added Skip Dialog On Telephone When Exchanging BGL!
Added Show Visual Clothes To Proxy Users in /clothes!
/switch -> Fast Account Switching
/pfind [Item Name] -> Pathfinds to the nearest dropped [Item Name] in the world.
For Current Version:

Added World Drop/Collect History (Like CCTV) -> /logs
Added Customizable Water Speed -> /speed;
Add REME Spin -> /options;
Add /song [Spotify song link] -> Singing Songs!
Added /autoharvest -> Auto Harvest Page;
Added /autoplant -> Auto Plant Page;
Added /harvest -> Enables Auto Harvest;
Added /plant -> Enables Auto Plant;
Added /pathfind -> Pathfinder Option Page;
Added /set1, /set2, /set3, /set4 -> Equip Saved Set Slot.
Added Pathfind Instant Continue After TP Back Option -> /Pathfind
Made Pathfinding look smoother;
Fixed /mods not working for some accounts;
Added 37 New Mods to /mods list.
Added Auto Reconnect When Stuck Logging.
Added "Join World" Option in /options -> "Mod Detect Settings"
Added Support DoorID to "Join World" When mod joins world in /options -> "Mod Detect Settings"
Added "Hide Private Messages" in /options;
Added /pvend [item name] -> Pathfinds to a vending machine containing cheapest item.
Instant Pathfinder!
Fixed Issues With /cd /dd /dropall /worlds /wrench etc.
Added Socks5 support (saveable) -> Log out of GT, then click both Shift keys on your keyboard and type 'socks'
Added Force Skip Update Item Data -> Log out of GT, then click both Shift keys on your keyboard and type 'skip'
Added Separate Option for Withdrawing Wls and Restocking Items -> /vend
Added Auto-fill password when trying to connect to an account. (Must have /switch enabled)
Auto Drill/Detonate in auto fish -> /options NEW:
Guardians added to mod list.
Better connection optimizations
Add /xsplit [%] (splits recently collected wls)
Add /lock (Auto Wrench Lock Apply Settings)
Added Wider Socks5 Proxy Support! PATCH:
Fixed Crash Problem on connection + packet 26.
Fixed /autopullall & /autobanall crash.
